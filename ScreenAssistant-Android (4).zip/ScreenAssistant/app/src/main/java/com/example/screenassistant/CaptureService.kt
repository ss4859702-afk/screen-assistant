package com.example.screenassistant

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

class CaptureService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_SNAP = "snap"
        const val ACTION_ASK = "ask"
        const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val KEY_REPLY = "reply"
        const val CHANNEL = "assistant"
        const val NOTIF_ID = 1
        const val MODEL = "claude-sonnet-5-5"
        const val SYSTEM = "Ти помічник, який бачить знімок екрана користувача. " +
            "Відповідай мовою питання, коротко і по суті. " +
            "Не повторюй паролі, ключі та інші секрети, які видно на екрані."
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val worker = Executors.newSingleThreadExecutor()
    private var lastShot: String? = null  // лише в пам'яті

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_SNAP -> snap()
            ACTION_ASK -> {
                val q = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(KEY_REPLY)?.toString()
                if (!q.isNullOrBlank()) ask(q)
            }
            ACTION_STOP -> {
                cleanup()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    // ---------- Запуск ----------
    private fun start(intent: Intent) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Assistant", NotificationManager.IMPORTANCE_LOW))

        val n = buildNotification("Готово. Натисніть «📷 Знімок», коли потрібно подивитись на екран.")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIF_ID, n)

        val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { cleanup(); stopSelf() }
        }, Handler(Looper.getMainLooper()))

        thread = HandlerThread("capture").also { it.start() }
        handler = Handler(thread!!.looper)

        val dm = resources.displayMetrics
        val r = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader = r
        display = p.createVirtualDisplay(
            "assistant", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
        display?.surface = null  // у спокої екран не знімається
    }

    // ---------- Знімок ----------
    private fun snap() {
        notify("Роблю знімок…")
        worker.execute {
            try {
                Thread.sleep(900)  // дати шторці сповіщень сховатись
                lastShot = capture() ?: throw Exception("не вдалося зробити знімок")
                notify("Знімок зроблено. Потягніть шторку й натисніть «✍ Питання».")
            } catch (e: Exception) {
                notify("Помилка: ${e.message}")
            }
        }
    }

    private fun capture(): String? {
        val r = reader ?: return null
        val d = display ?: return null
        r.acquireLatestImage()?.close()  // скинути старі кадри
        val result = AtomicReference<String?>(null)
        val latch = CountDownLatch(1)

        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (result.get() == null) {
                    val p = img.planes[0]
                    val rowPadding = p.rowStride - p.pixelStride * img.width
                    val full = Bitmap.createBitmap(
                        img.width + rowPadding / p.pixelStride, img.height, Bitmap.Config.ARGB_8888
                    )
                    full.copyPixelsFromBuffer(p.buffer)
                    val cropped = Bitmap.createBitmap(full, 0, 0, img.width, img.height)
                    val scale = minOf(1.0, 1280.0 / maxOf(cropped.width, cropped.height))
                    val small = Bitmap.createScaledBitmap(
                        cropped, (cropped.width * scale).toInt(), (cropped.height * scale).toInt(), true
                    )
                    val out = ByteArrayOutputStream()
                    small.compress(Bitmap.CompressFormat.JPEG, 80, out)
                    result.set(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
                    latch.countDown()
                }
            } finally { img.close() }
        }, handler)

        d.surface = r.surface          // вмикаємо захоплення
        latch.await(3, TimeUnit.SECONDS)
        d.surface = null               // одразу вимикаємо
        r.setOnImageAvailableListener(null, null)
        return result.get()
    }

    // ---------- Питання ----------
    private fun ask(question: String) {
        val shot = lastShot
        if (shot == null) { notify("Спершу натисніть «📷 Знімок»."); return }
        notify("Думаю…")
        worker.execute {
            try { notify(callApi(question, shot)) }
            catch (e: Exception) { notify("Помилка: ${e.message}") }
        }
    }

    private fun callApi(question: String, b64: String): String {
        val key = getSharedPreferences("prefs", MODE_PRIVATE).getString("key", "") ?: ""
        val content = JSONArray()
            .put(JSONObject().put("type", "image").put("source", JSONObject()
                .put("type", "base64").put("media_type", "image/jpeg").put("data", b64)))
            .put(JSONObject().put("type", "text").put("text", question))
        val body = JSONObject()
            .put("model", MODEL).put("max_tokens", 1000).put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))

        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000; c.readTimeout = 60000
        c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }

        val ok = c.responseCode in 200..299
        val text = (if (ok) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (!ok) throw Exception("API ${c.responseCode}: " +
            runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrDefault(text.take(200)))

        val arr = JSONObject(text).getJSONArray("content")
        return buildString {
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                if (b.getString("type") == "text") append(b.getString("text"))
            }
        }
    }

    // ---------- Сповіщення ----------
    private fun notify(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun buildNotification(text: String): Notification {
        fun svc(code: Int, action: String) = PendingIntent.getService(
            this, code, Intent(this, CaptureService::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val snap = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_camera), "📷 Знімок", svc(1, ACTION_SNAP)
        ).build()

        val ri = RemoteInput.Builder(KEY_REPLY).setLabel("Ваше питання про екран").build()
        val askPi = PendingIntent.getService(
            this, 2, Intent(this, CaptureService::class.java).setAction(ACTION_ASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE  // потрібно для RemoteInput
        )
        val ask = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_help), "✍ Питання", askPi
        ).addRemoteInput(ri).build()

        val stop = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Стоп", svc(3, ACTION_STOP)
        ).build()

        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Screen Assistant")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setOngoing(true)
            .addAction(snap).addAction(ask).addAction(stop)
            .build()
    }

    // ---------- Прибирання ----------
    private fun cleanup() {
        lastShot = null
        display?.release(); display = null
        reader?.close(); reader = null
        val p = projection; projection = null
        p?.stop()
        thread?.quitSafely(); thread = null
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }
}
