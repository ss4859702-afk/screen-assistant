package com.example.screenassistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private lateinit var keyField: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun lp() = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = (12 * d).toInt() }

        root.addView(TextView(this).apply {
            text = "Screen Assistant"; textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "ШІ, який дивиться на ваш екран і відповідає на питання.\n\n" +
                "1. Введіть API-ключ Anthropic і натисніть «Почати».\n" +
                "2. Дайте дозвіл на захоплення екрана (оберіть «Весь екран»).\n" +
                "3. Відкрийте будь-який застосунок, потягніть шторку сповіщень і натисніть «📷 Знімок».\n" +
                "4. Шторка сховається, знімок буде зроблено. Знову потягніть шторку, натисніть «✍ Питання», напишіть питання — відповідь з'явиться у сповіщенні."
        }, lp())

        keyField = EditText(this).apply {
            hint = "API-ключ (sk-ant-...)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(getSharedPreferences("prefs", MODE_PRIVATE).getString("key", ""))
        }
        root.addView(keyField, lp())

        root.addView(Button(this).apply {
            text = "Почати"
            setOnClickListener { onStartClicked() }
        }, lp())
        root.addView(Button(this).apply {
            text = "Зупинити й відкликати дозвіл"
            setOnClickListener {
                startService(Intent(this@MainActivity, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
                Toast.makeText(this@MainActivity, "Зупинено", Toast.LENGTH_SHORT).show()
            }
        }, lp())

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun onStartClicked() {
        val key = keyField.text.toString().trim()
        if (key.isEmpty()) {
            Toast.makeText(this, "Введіть API-ключ", Toast.LENGTH_SHORT).show(); return
        }
        getSharedPreferences("prefs", MODE_PRIVATE).edit().putString("key", key).apply()

        AlertDialog.Builder(this)
            .setTitle("Дозвіл на сканування екрана")
            .setMessage(
                "Знімок екрана робиться ТІЛЬКИ коли ви натискаєте «📷 Знімок» у сповіщенні. " +
                "Він надсилається до Anthropic API разом із вашим питанням, не зберігається на пристрої " +
                "і видаляється з пам'яті після зупинки.\n\nНа екрані можуть бути особисті дані. Дозволити?"
            )
            .setPositiveButton("Дозволити") { _, _ ->
                val mpm = getSystemService(MediaProjectionManager::class.java)
                @Suppress("DEPRECATION")
                startActivityForResult(mpm.createScreenCaptureIntent(), 100)
            }
            .setNegativeButton("Скасувати", null)
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .setAction(CaptureService.ACTION_START)
                .putExtra(CaptureService.EXTRA_CODE, resultCode)
                .putExtra(CaptureService.EXTRA_DATA, data)
            startForegroundService(i)
            Toast.makeText(this, "Готово! Потягніть шторку сповіщень.", Toast.LENGTH_LONG).show()
        } else if (requestCode == 100) {
            Toast.makeText(this, "Дозвіл не надано", Toast.LENGTH_SHORT).show()
        }
    }
}
